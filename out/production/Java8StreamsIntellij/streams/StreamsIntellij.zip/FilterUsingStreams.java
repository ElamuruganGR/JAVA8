package streams;

import java.util.Arrays;
import java.util.List;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.function.Predicate;

public class FilterUsingStreams {

    public  static  void  main(String[] args){
        List<Integer> values = Arrays.asList(12,20,35,46,55,68,75);
        //List<Integer> values = Arrays.asList(12,46,68);
        int result = 0;
        for(int i: values){
            if(i%5 == 0){
                result += i ;
            }
        }
        Predicate<Integer> predicate = new Predicate<Integer>() {
            @Override
            public boolean test(Integer integer) {
                return integer%5 == 0;
            }
        };
        BinaryOperator<Integer> binaryOperator = new BinaryOperator<Integer>() {
            @Override
            public Integer apply(Integer integer, Integer integer2) {
                return integer+integer2;
            }
        };
        Function<Integer, Integer> function = new Function<Integer, Integer>() {
            @Override
            public Integer apply(Integer integer) {
                return integer*2;
            }
        };
        //Add only numbers divisible by 5
        System.out.println("Add only numbers divisible by 5");
        System.out.println("using Filter without Lambda -- "+values.stream().filter(predicate).reduce(0,binaryOperator));
        System.out.println("using Filter with Lambda-- "+values.stream().filter(i -> i%5==0).reduce(0,(a,b) -> a+b));

        //Double the numbers divisible by 5 and add
        System.out.println("Double the numbers divisible by 5 and add");
        System.out.println("using Filter without Lambda -- "+values.stream()
                                                                    .filter(predicate)
                                                                    .map(function)
                                                                    .reduce(0,binaryOperator));
        System.out.println("using Filter with Lambda-- "+values.stream()
                                                                .filter(i -> i%5==0)
                                                                .map(a -> a*2)
                                                                .reduce(0,(a,b) -> a+b));
        //print the double value of first occurence of the number divisible by 5
        System.out.println("print the double value of first occurence of the number divisible by 5");
        System.out.println("using Filter with Lambda-- "+values.stream()
                                                                .filter(i -> i%5==0)
                                                                .map(a -> a*2)
                                                                .findFirst()
                                                                .orElse(0));
    }
}
